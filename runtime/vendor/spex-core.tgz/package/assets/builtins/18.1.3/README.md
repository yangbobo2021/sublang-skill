# sublang/playbooks

The built-in playbooks of Playbook 18.1.3, as the spec package Spex ships and seeds.
