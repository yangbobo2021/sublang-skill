# sublang/playbooks

The built-in playbooks of Playbook 18.1.4, as the spec package Spex ships and seeds.
